#files=`ls`
files=$("ls")

echo $files
