#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
  //int system(const char *command);
  system("ls -l -a -h");
  return 0;
}
